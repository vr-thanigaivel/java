
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	  
		Scanner scan = new Scanner (System.in);
		System.out.println("enter ur tamil  mark");
		int tamil=scan.nextInt();
		System.out.println("enter ur english  mark");
		int english=scan.nextInt();
		System.out.println("enter ur maths  mark");
		int maths=scan.nextInt();
		System.out.println("enter ur science  mark");
	    int science=scan.nextInt();
	    System.out.println("enter ur social  mark");
	    int social=scan.nextInt();
	    
	    if(tamil<35||english<35||maths<35||science<35||social<35){
	         System.out.println("fail");
	    }

	    else{
	        int total = (tamil+english+maths+science+social);
	        System.out.println("total "+total);
	        float average = (float)total/5;
	        System.out.printf("Average %.2f %%",average);
	        
	    }
	   
	}
}