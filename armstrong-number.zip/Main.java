import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int a = scan.nextInt();
	int digit_count=0;
	int temp=a;
	while(temp>0){
	    temp/=10;
	    digit_count++;
	}
	temp=a;
    int	sum=0,pow;
	while(temp>0){
	    pow=1;
	    for(int i=1;i<=digit_count;i++)
	    pow=pow*(temp%10);
	    sum+=pow;
	    temp/=10;
	    
	}
	if(sum==a)
	System.out.printf("it is armstrng no");
	else
	System.out.print("not armstrng no");
	
	}
}