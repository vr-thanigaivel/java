import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
         StringBuilder sb = new   StringBuilder(str);
          System.out.println(sb);
          sb.append("syed radha");
           System.out.println(sb);
           sb.insert(0,"Hey!");
            System.out.println(sb);
            sb.replace(5,13,"patturose");
             System.out.println(sb);
             sb.delete(5,14);
              System.out.println(sb);
    }
}