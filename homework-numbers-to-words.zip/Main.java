import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
   
        Scanner sc = new Scanner(System.in);
      String input = sc.nextLine();

       
        if (input.length() != 2 || !input.matches("\\d{2}")) {
           return;
        }

        int number = Integer.parseInt(input);

        String[] oneToNine = {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
        String[] tenToNineteen = {"ten", "eleven", "twelve", "thirteen", "fourteen",
                                  "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
        String[] tens = {"", "", "twenty", "thirty", "forty", "fifty", 
                         "sixty", "seventy", "eighty", "ninety"};

        String output;
        if (number >= 10 && number <= 19) {
            output = tenToNineteen[number - 10];
        } else {
            int tensPlace = number / 10;
            int onesPlace = number % 10;
            output = tens[tensPlace];
            if (onesPlace != 0) {
                output += "-" + oneToNine[onesPlace];
            }
        }

        System.out.println("In words: " + output);
    }
}
