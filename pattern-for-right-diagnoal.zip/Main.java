import java.util.Scanner;

public class Main
{
	public static void main(String[] args){
	Scanner scan = new Scanner(System.in);
	int num=scan.nextInt();
	for(int i=1;i<=num;i++){
	 for(int j=1;j<=num;j++) {
	     if(i+j==num+1)
	     System.out.print("1");
	     else
	     	     System.out.print("0");
	     
	    
	   }
	     System.out.println();
	   
	   
	}
	}
}