import java.util.*;

public class Main {
  public static void main(String[] args) {
    Scanner obj = new Scanner(System.in);
    int size=obj.nextInt(),temp;
    int numbers[] = new int[size];
    for(int i=0;i<size;i++){
      numbers[i]=obj.nextInt();
    }
    int n1, n2 , prime_pair_count=0;
    System.out.print("Prime pairs count is: ");
    for(int i=0;i<size-1;i++){
      n1=numbers[i];
      n2=numbers[i+1];
      int n_count=0;
      boolean check=true;
      for(int j=1;j<=2;j++) {
        for(int k=2;k<n1;k++){
          if(n1%k==0){
            check=false;
            break;
          }
        }
        if(check) n_count++;
        n1=n2;
      }
      if(n_count==2) prime_pair_count++;
    }
    System.out.print(prime_pair_count);
  }
}