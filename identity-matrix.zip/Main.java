
        import java.util.*;
public class Main {
    public static void main(String[] args) {
      Scanner obj=new Scanner(System.in);
      int row = obj.nextInt(),cols = obj.nextInt();
      if(row==cols){
        int array[][] = new int[row][cols];
        for(int i=0;i<row;i++){
          for(int j=0;j<cols;j++){
            array[i][j]=obj.nextInt();
          }
        }
    boolean a =true;
        for(int i=0;i<cols;i++){
          for(int j=1;j<row;j++){
             if(i==j&&array[i][j]!=1){
              a =false;
             }
             if(i!=j&&array[i][j]!=0){
               a=false;
             }
          }
        }
        if(a)
          System.out.println(" identity matrix");
        else
          System.out.println(" not identity matrix");
      }
      else{
        System.out.println("not a identity matrix!!");
      }
      
  }
}