import java.util.*;
public class Main {
    public static void main(String[] args) {
      Scanner obj=new Scanner(System.in);
      int size = obj.nextInt();
      int array[] = new int[size];
      for(int i=0;i<size;i++)
        array[i]=obj.nextInt();
      int beforemax=0, aftermin=0, max=array[0], min=array[0];
      int max_index=0, min_index=0;
      for(int i=1;i<size;i++){
       if(max<array[i]){
         max=array[i]; max_index=i;
       }
       if(min>array[i]){
         min=array[i]; min_index=i;
       }
      }
      for(int i=0;i<max_index;i++) beforemax+=array[i];
      for(int i=min_index+1;i<size;i++) aftermin+=array[i];
      System.out.println(beforemax+" "+aftermin);
  }
}