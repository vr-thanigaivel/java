import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        char arr[] = str.toCharArray();
        for(char i: arr){
            if(i>='A' && i<='Z')
              System.out.println(i+" ");
        }
         
    
    }
}