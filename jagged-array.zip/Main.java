import java.util.*;
public class Main {
    public static void main(String[] args) {
      Scanner obj = new Scanner(System.in);
      
      int row=obj.nextInt();
      int jaggedarray[][] = new int[row][];
      
      for(int i=0;i<row;i++){
        int cols=obj.nextInt();
        jaggedarray[i]= new int[cols];
        for(int j=0;j<cols;j++){
            jaggedarray[i][j]=obj.nextInt();
        }
      }
      
      for(int i=0;i<row;i++){
        for(int j=0;j<jaggedarray[i].length;j++){
            System.out.print(jaggedarray[i][j]+" ");
        }
        System.out.println();
      }
  }
}
