import java.util.Scanner;

public class Main
{
	public static void main(String[] args){
	Scanner scan = new Scanner(System.in);
	int num=scan.nextInt();
	for(int i=1;i<=num;i++){
	    System.out.print("*");  print pota horizontal and println pota vertical
	}
	}
}