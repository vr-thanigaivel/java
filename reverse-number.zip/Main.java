import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int a = scan.nextInt();
	int reversed = 0;
    while(a!=0){
        int digit = a % 10;
        reversed= reversed * 10 + digit;
        a = a/10;
    }
    System.out.println("reversed number:"+reversed);
	}
}