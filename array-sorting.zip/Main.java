import java.util.*;
public class Main {
  public static void main(String[] args) {
    Scanner obj = new Scanner(System.in);
    int size=obj.nextInt(),temp;
    int numbers[] = new int[size];
    for(int i=0;i<size;i++){
      numbers[i]=obj.nextInt();
    }
    for(int i=0;i<size;i++){
      for(int j=i+1;j<size;j++){
        if(numbers[i]>numbers[j]){
          temp =numbers[i];
          numbers[i]=numbers[j];
          numbers[j]=temp;
        }
      }
    }
    for(int i=0;i<size;i++){
      System.out.print(numbers[i]+" ");
    }
  }
}