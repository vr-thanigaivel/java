import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
			Scanner scan = new Scanner (System.in);
			char ch = scan.next().charAt(0);
			
			if(ch>='a' && ch<='z')
			System.out.print((char)(ch-32));
				if(ch>='A' && ch<='Z')
			System.out.print((char)(ch+32));
			
	}
}