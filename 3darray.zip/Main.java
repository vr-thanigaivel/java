import java.util.*;

public class Main {

    public static void main(String[] args) {
      Scanner obj = new Scanner(System.in);
      int s1=obj.nextInt(),s2=obj.nextInt(),s3=obj.nextInt();
      int _3Darray[][][] = new int[s1][s2][s3];
      for(int i=0;i<s1;i++){
        for(int j=0;j<s2;j++){
          for(int k=0;k<s3;k++){
            _3Darray[i][j][k]=obj.nextInt();
          }
        }
      }
      for(int i=0;i<s1;i++){
        for(int j=0;j<s2;j++){
          for(int k=0;k<s3;k++){
            System.out.print(_3Darray[i][j][k]+" ");
          }
          System.out.println();
        }
        System.out.println();
      }
  }
}