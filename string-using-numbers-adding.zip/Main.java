import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        char arr[] = str.toCharArray();
        int sum=0,num,len=arr.length;
        
        int i=0;
        do{
            num=0;
            while(i<len && arr[i]>='0' && arr[i]<='9'){
                num = num*10+(arr[i]-'0');
                i++;
            }
            sum+=num;
            i++;
        }
        while(i<len);
           System.out.println(sum);
       
            }
        }
     
         

        
        
        
        
        
        
        