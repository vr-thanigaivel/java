import java.util.*;
public class Main{
    public static void main(String[]args){
        Scanner obj = new Scanner(System.in);
        int size=obj.nextInt();
        obj.nextLine();
        String str[] =  new String[size];
        for(int i=0;i<5;i++){
            str[i]=obj.nextLine();
        }
        for(String s : str){
        System.out.println(s);
    }
    }
}